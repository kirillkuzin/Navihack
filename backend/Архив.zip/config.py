EMAIL = 'offkirillkuzin@gmail.com'
PASSWORD = 'kirkuz135'
