BASE_URL = 'https://staging-api.naviaddress.com/api/v1.5/'
SESSIONS_ENDPOINT = BASE_URL + 'Sessions/'
ADDRESSES_ENDPOINT = BASE_URL + 'Addresses/'
